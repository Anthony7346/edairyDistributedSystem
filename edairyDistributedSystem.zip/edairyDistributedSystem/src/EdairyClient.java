import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

public class EdairyClient extends JFrame {
    private JLabel dayLabel;
    private JTextField dayField;
    private JLabel timeLabel;
    private JTextField timeField;
    private JLabel activityLabel;
    private JTextField activityField;
    private JLabel descriptionLabel;
    private JTextArea descriptionArea;
    private JLabel planIdLabel;
    private JTextField planIdField;
    private JButton submitButton;
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;

    public EdairyClient() {
        setTitle("Edairy");
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        dayLabel = new JLabel("Day:");
        dayField = new JTextField(20);
        timeLabel = new JLabel("Time:");
        timeField = new JTextField(20);
        activityLabel = new JLabel("Activity:");
        activityField = new JTextField(20);
        descriptionLabel = new JLabel("Description:");
        descriptionArea = new JTextArea(5, 20);
        planIdLabel = new JLabel("Plan ID:");
        planIdField = new JTextField(20);
        submitButton = new JButton("Submit");

        try {
            socket = new Socket("localhost", 4444);
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }

        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String day = dayField.getText();
                String time = timeField.getText();
                String activity = activityField.getText();
                String description = descriptionArea.getText();
                String planId = planIdField.getText();
                String message = day + "," + time + "," + activity + "," + description + "," + planId;

                out.println(message);
                JOptionPane.showMessageDialog(null, "Data sent to server.");
            }
        });

        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(dayLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        panel.add(dayField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(timeLabel, gbc);
                
        gbc.gridx = 1;
        gbc.gridy = 1;
        panel.add(timeField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(activityLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        panel.add(activityField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(descriptionLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 3;
        panel.add(descriptionArea, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(planIdLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 4;
        panel.add(planIdField, gbc);

        gbc.gridx = 1;
        gbc.gridy = 5;
        panel.add(submitButton, gbc);

        add(panel);
    }

    public static void main(String[] args) {
        EdairyClient frame = new EdairyClient();
        frame.setVisible(true);
    }
}
