import java.io.*;
import java.net.*;
import javax.swing.*;
import java.awt.*;

public class EdairyServer extends JFrame {
    private JTextArea textArea;
    private ServerSocket serverSocket;
    private Socket clientSocket;
    private PrintWriter out;
    private BufferedReader in;

    public EdairyServer() {
        super("Edairy Server");
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        textArea = new JTextArea();
        textArea.setEditable(false);
        add(new JScrollPane(textArea), BorderLayout.CENTER);

        try {
            serverSocket = new ServerSocket(4444);
            textArea.append("Server started and listening on port 4444\n");

            clientSocket = serverSocket.accept();
            textArea.append("Client connected\n");

            out = new PrintWriter(clientSocket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                textArea.append("Received from client: " + inputLine + "\n");
                // Parse the received data here
                // Perform appropriate actions here, such as storing the data in a database or displaying it on the screen
            }

            out.close();
            in.close();
            clientSocket.close();
            serverSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        EdairyServer frame = new EdairyServer();
        frame.setVisible(true);
    }
    
}